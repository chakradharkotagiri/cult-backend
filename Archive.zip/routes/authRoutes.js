
const express = require('express');
const { register, login } = require('../controllers/authController');
const router = express.Router();

// Register route
rrouter.post('/signup', (req, res) => {
    res.send('Signup route is working');
  });
  
// Login route
router.post('/login', login);

// Export the router
module.exports = router;